# passvault
Team development project of a program for storing passwords.

Authors: Калиев Данияр, Корепанова Вероника, Михайлов Леонид, Котов Николай, Закиров Раиль, Круглов Илья В.
